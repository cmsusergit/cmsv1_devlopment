export default class StudentPastAcademicInfo{


  constructor(stuCourseName=''){
    {
      this.stuAcadid  = 0;
      this.stuCourseName= stuCourseName;
      this.stuBoardUni= '';
      this.stuPassingYear= '';
      this.stuGrade= 0;
      this.stuGradeSystem='CPI'
      this.stuId=0;
  }
}}
