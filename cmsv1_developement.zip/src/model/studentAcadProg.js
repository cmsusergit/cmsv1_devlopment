export default class StudentAcadProg{
  constructor(){
   this.studentAcadProgressId=0;
   this.studentAcadProgressBatchid=0;
   this.studentAcadProgressStatus=1;
   this.studentAcadProgressUpdateDate=new Date();
   this.studentAcadProgressSem=1;
   this.studentInfoStuId=0;
   this.studentAcadProgressClassid=0;
 }
}
