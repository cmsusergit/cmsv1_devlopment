 <template>
    <div style="width:100%;" class="is-radiusless box">

      <h1 class="subtitle has-text-weight-bold has-text-centered">
        <u>PART-C</u>
        <br>
        <b>FEEDBACK PERFORMANCE</b>
      </h1>

    <div class="has-text-weight-bold">
    </div>
  </div>
</template>
<script>
import {mapGetters} from 'vuex'
export default {
  name: 'SelfAppraisalPartA',
  data() {
    return {
    }
  },
  computed: {
    ...mapGetters([
    ]) //....
  },
  watch:{
  },
  mounted()
  {},
  methods: {
  }
}
</script>






style>
</style>
