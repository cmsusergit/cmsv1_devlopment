'use strict';

module.exports = function(Apiteaching) {

};
