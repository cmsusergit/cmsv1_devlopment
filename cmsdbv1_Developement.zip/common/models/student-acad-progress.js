'use strict';

module.exports = function(Studentacadprogress) {

};
