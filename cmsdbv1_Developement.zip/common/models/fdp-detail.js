'use strict';

module.exports = function(Fdpdetail) {

};
