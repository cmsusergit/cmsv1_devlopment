'use strict';

module.exports = function(Departmentinfo) {

};
