'use strict';

module.exports = function(Courseinfo) {

};
