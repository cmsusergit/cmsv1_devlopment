'use strict';

module.exports = function(Courseobj) {

};
