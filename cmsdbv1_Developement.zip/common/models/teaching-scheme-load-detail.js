'use strict';

module.exports = function(Teachingschemeloaddetail) {

};
