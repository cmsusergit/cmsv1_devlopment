'use strict';

module.exports = function(Studentguardianinfo) {

};
