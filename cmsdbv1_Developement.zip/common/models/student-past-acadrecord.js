'use strict';

module.exports = function(Studentpastacadrecord) {

};
