'use strict';

module.exports = function(Facultypersonalinfo) {

};
