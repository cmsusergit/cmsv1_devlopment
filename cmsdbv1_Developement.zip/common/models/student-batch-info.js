'use strict';

module.exports = function(Studentbatchinfo) {

};
