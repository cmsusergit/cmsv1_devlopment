'use strict';

module.exports = function(Teachingloadinfo) {

};
