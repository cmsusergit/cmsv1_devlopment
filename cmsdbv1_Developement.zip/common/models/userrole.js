'use strict';

module.exports = function(Userrole) {

};
