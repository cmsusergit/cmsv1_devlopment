'use strict';

module.exports = function(Empeducationdetail) {

};
